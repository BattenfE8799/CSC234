// CSC 234
// M1T1-Orientation
// Elizabeth Battenfield
// 8/16/2021

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
  cout << "Hello!\n\n";
  cout << "I'm Elizabeth Battenfield.\n\n";
  cout << "This semester I have a full study load!\n\n";
  cout << "I am studying Advanced C++ and Advanced Python!\n\n";
  cout << "I am also studying:\n      Operating System Concenpts,\n      System Analysis and Design, and\n      Linux/Single User (aka Red Hat System Administration 1)\n\n";
  cout << "I am a single mother, I am currently not working as I am a full-time student.\n\n";
  cout << "I am planning on graduating this coming spring, and hope to get a good job using what I've learned here at FTCC.\n\n";
  cout << "My hobbies include listening to music, reading, playing video games, and watching youtube/twitch streamers.\n\n";
  cout << " I am also spending my time making my own personal projects using Python and C++.\n\n";
  cout << "My current long term project is a text-based Pokemon game.\n";

}